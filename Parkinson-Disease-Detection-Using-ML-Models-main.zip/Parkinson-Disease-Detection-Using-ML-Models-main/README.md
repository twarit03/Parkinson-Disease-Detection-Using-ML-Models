# Parkinson-Disease-Detection-Using-ML-Models
I have successfully executed a project utilizing machine learning techniques on voice frequency datasets. This endeavor highlights my proficiency in developing ML models tailored for medical applications, underscoring my expertise in data analysis and predictive modeling.
